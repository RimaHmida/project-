<?php
	include '../config.php';
	include_once '../Model/Block.php';
	class BlockC {
		function afficherblocks(){
			$sql="SELECT * FROM blocks";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				return $liste;
			}
			catch(Exception $e){
				die('Erreur:'. $e->getMeesage());
			}
		}
		function supprimerblock($id){
			$sql="DELETE FROM blocks WHERE Id=:id";
			$db = config::getConnexion();
			$req=$db->prepare($sql);
			$req->bindValue(':id', $id);
			try{
				$req->execute();
			}
			catch(Exception $e){
				die('Erreur:'. $e->getMeesage());
			}
		}
		function ajouterblock($block){
			$sql="INSERT INTO blocks (Id, Nom, Nbrsalles, Typesalles) 
			VALUES (:id,:nom,:nbrsalles,:typesalles)";
			$db = config::getConnexion();
			try{
				$query = $db->prepare($sql);
				$query->execute([
					'id' => $block->getId(),
					'nom' => $block->getNom(),
					'nbrsalles' => $block->getNbrsalles(),
					'typesalles' => $block->getTypesalles()
                ]);			
			}

			catch (Exception $e){
				echo 'Erreur: '.$e->getMessage();
			}			
		}
		function recupererblock($id){
			$sql="SELECT * from blocks where Id=$id";
			$db = config::getConnexion();
			try{
				$query=$db->prepare($sql);
				$query->execute();

				$adherent=$query->fetch();
				return $adherent;
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}
		}
		
		function modifierblock($block, $id){
			try {
				$db = config::getConnexion();
				$query = $db->prepare(
					'UPDATE blocks SET 
						Nom= :nom, 
						Nbrsalles= :nbrsalles, 
						Typesalles= :typesalles
					WHERE Id= :id'
				);
				$query->execute([
					'id' => $block->getId(),
					'nom' => $block->getNom(),
					'nbrsalles' => $block->getNbrsalles(),
					'typesalles' => $block->getTypesalles(),
					'id' => $id
				]);
				echo $query->rowCount() . " records UPDATED successfully <br>";
			} catch (PDOException $e) {
				$e->getMessage();
			}
		}

	}
?>